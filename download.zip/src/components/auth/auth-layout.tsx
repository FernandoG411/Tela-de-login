import type { ReactNode } from 'react';
import Image from 'next/image';

export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <>
      <Image
        src="https://media1.giphy.com/media/v1.Y2lkPTc5MGI3NjExcjY1bGF5anp5OHBjbHAycWJ2aW9lbDRtbzB2bWR6eWt2bDYxYnoxdSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/3ohjV5Bc9R3WBSgHxm/giphy.gif"
        alt="Background GIF"
        layout="fill"
        objectFit="cover"
        className="fixed inset-0 w-full h-full z-[-2]"
        unoptimized
      />
      <div className="fixed inset-0 bg-black/50 z-[-1]" />
      <main className="flex min-h-screen flex-col items-center justify-center p-4">
        <div className="flex w-full max-w-sm flex-col items-center space-y-6">
          <div className="w-full bg-card/80 backdrop-blur-sm rounded-lg">
            {children}
          </div>
        </div>
      </main>
    </>
  );
}
