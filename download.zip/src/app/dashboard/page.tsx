import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import Link from 'next/link';

export default function DashboardPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-headline">Bem-vindo!</CardTitle>
          <CardDescription>Você fez login com sucesso.</CardDescription>
        </CardHeader>
        <CardContent>
          <p>Este é o seu painel. Mais recursos em breve.</p>
          <Link href="/login" className="w-full">
            <Button variant="outline" className="mt-6 w-full">
              Sair
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
